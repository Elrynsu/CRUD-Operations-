async function students() {
    const formEl = document.querySelector('.container-form #form');
    const baseURL = 'http://localhost:3030/jsonstore/collections/students';
    formEl.addEventListener('submit', submitName);

    const tableEl = document.querySelector('#results tbody');

    const response = await fetch(baseURL);
    const data = await response.json();

    Object.values(data).forEach((entry) => {

        const entryData = {
            firstName: entry.firstName,
            lastName: entry.lastName,
            facultyNumber: entry.facultyNumber,
            grade: Number(entry.grade)
        }
        const uniqueId = entry._id

        const trEl = document.createElement('tr');
        trEl.className = uniqueId;

        const firstNameCell = trEl.insertCell(0);
        firstNameCell.textContent = entryData.firstName;

        const lastNameCell = trEl.insertCell(1);
        lastNameCell.textContent = entryData.lastName;

        const facultyNumber = trEl.insertCell(2);
        facultyNumber.textContent = entryData.facultyNumber;

        const grade = trEl.insertCell(3);
        grade.textContent = entryData.grade;

        tableEl.appendChild(trEl);
    });
    

    async function submitName(ev) {
        
        const formData = Object.fromEntries(new FormData(ev.currentTarget));
        const formValues = Object.values(formData);

        const fieldMissing = formValues.some(value => value === '');

        if(fieldMissing) {
            throw new Error('Please fill in the required fields.')
        } else {
            const response = await fetch(baseURL, {
                method: 'POST',
                headers: {
                    'Content-type': 'application/json'
                },
                body: JSON.stringify({
                    firstName: formData.firstName,
                    lastName: formData.lastName,
                    facultyNumber: formData.facultyNumber,
                    grade: formData.grade
                })
            });

            if(!response.ok) {
                throw new Error('Failed to submit the form!')
            }
            
        }

    }
}
students();