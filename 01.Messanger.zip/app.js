function attachEvents() {

    const baseURL = ' http://localhost:3030/jsonstore/messenger';
    const messagesBox = document.querySelector('#messages');

    document.querySelector('#submit').addEventListener('click', generateMsg)
    document.querySelector('#refresh').addEventListener('click', loadAllMsg)

    function generateMsg() {
        
        const [author, content] = [document.querySelector('[name="author"]'), document.querySelector('[name="content"]')]
        
        if(!author.value || !content.value) {
            throw new Error('Please fill the - Name - Message - fields.')
        } else {

            fetch(baseURL, {
                method: 'POST',
                headers: {
                    'Content-type': 'application/json'
                },
                body: JSON.stringify({
                    author: author.value,
                    content: content.value,
                })
            })
            .catch(err => console.error(err.message));

            author.value = '';
            content.value = '';
        }
    };

    function loadAllMsg() {

        fetch(baseURL)
            .then(res => {
                if(res.ok) {
                    return res.json();
                }
            })
            .then(messages => {
                const msgTexts = Object.values(messages);
                
                messagesBox.value = msgTexts.map(({ author, content }) => `${author}: ${content}`).join('\n');
            })
            .catch(err => console.error(err.message))
    }

}

attachEvents();