function attachEvents() {
    const baseURL = 'http://localhost:3030/jsonstore/phonebook';

    const phoneBookUlEl = document.querySelector('#phonebook');
    const loadBtn = document.querySelector('#btnLoad');
    //Delete button created inside LI element of PhonebookEl.
    //Functionallity of the button is in 'onClickDelete', but it's been created and called inside 'LoadContacts';

    const createBtn = document.querySelector('#btnCreate');
    createBtn.addEventListener('click', profileCreate)

    loadBtn.addEventListener('click', loadContacts);


    function loadContacts() {

        fetch(baseURL)
            .then(res => res.json())
            .then(data => {
                phoneBookUlEl.innerHTML = '';
                const dataInfo = Object.values(data);
                console.log(dataInfo)

                for (let contact of dataInfo) {
                    const liEl = document.createElement('li');
                    liEl.id = contact._id; 
                    liEl.textContent = `${contact.person}: ${contact.phone}`; 
        
                    const deleteBtn = document.createElement('button');
                    deleteBtn.textContent = 'Delete';
                    deleteBtn.className = 'delete-btn';
                    deleteBtn.addEventListener('click', onClickDelete);
                    liEl.appendChild(deleteBtn);
                    phoneBookUlEl.appendChild(liEl);
                }
            })
            .catch(err => console.error('Error:', err.message)); 
    };

    function onClickDelete(ev) {

        const uniqueID = ev.target.parentNode.id;
        ev.target.parentNode.remove();

        fetch(`${baseURL}/${uniqueID}`, {
            method: 'DELETE'
        })
            .catch(err => console.error(err.message))
    };
    //Creates new Contact, also keep in mind, create button automatically refreshes Contact Lists 
    //by just calling the loadContacts function once a successful entry is created.
    function profileCreate() {

        const [person, phone] = [document.querySelector('#person'), document.querySelector('#phone')];

        if (person.value === '' || phone.value === '') return;

        fetch(baseURL, {
            method: 'POST',
            headers: {
                'Content-type': 'application/json'
            },
            body: JSON.stringify({
                person: person.value,
                phone: phone.value
            })
        })
            .then(res => {
                if (!res.ok) throw new Error('Failed to send data');
                return res.json();
            })
            .then(data => {
                person.value = '';
                phone.value = '';
                loadContacts();
            })
            .catch(err => console.error(err.message));

    }

}

attachEvents();